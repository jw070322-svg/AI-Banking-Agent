Set-Location -LiteralPath $PSScriptRoot
python -m first_agent.server --port 8765
