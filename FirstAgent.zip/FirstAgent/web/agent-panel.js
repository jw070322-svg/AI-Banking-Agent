(()=>{'use strict';
const css=document.createElement('style');css.textContent=`#agent-launch{position:fixed;bottom:22px;right:22px;z-index:80;border:0;border-radius:24px;background:#4d4b9f;color:white;padding:14px 22px;cursor:pointer}#agent-panel{position:fixed;inset:24px 24px 24px auto;width:min(570px,calc(100vw - 48px));z-index:100;background:#fff;border:1px solid #deddeb;border-radius:18px;box-shadow:0 12px 60px #20204040;overflow:auto;padding:22px;font:14px/1.7 system-ui;color:#35445e}#agent-panel[hidden]{display:none}#agent-panel button{margin:4px;border:1px solid #d7d9e5;padding:7px 12px;border-radius:8px;background:#f7f7fc;cursor:pointer}#agent-panel input{padding:8px;border:1px solid #ccc;border-radius:6px;width:96%}#agent-panel pre{white-space:pre-wrap;word-break:break-word;font-size:12px;background:#f6f7fa;padding:12px;max-height:48vh;overflow:auto}#agent-close{float:right}`;document.head.append(css);
const launch=document.createElement('button');launch.id='agent-launch';launch.textContent='Agent · 对话与转账';
const panel=document.createElement('section');panel.id='agent-panel';panel.hidden=true;
panel.innerHTML='<button id="agent-close">关闭</button><h2>首版 Banking Agent</h2><p>本地模拟 · 持久化账本 · 所有金额使用整数分</p><button id="agent-consent">开启演示查询与交易权限</button><p>例如：分析账单并检查订阅；给张三转账 800 元；什么是债务比率</p><form id="agent-form"><label for="agent-message">你的需求</label><input id="agent-message" required maxlength="2000" autocomplete="off"><button>发送</button></form><div id="agent-steps" aria-live="polite"></div><pre id="agent-output">等待请求</pre><div id="agent-confirm" hidden><p id="agent-preview"></p><label>红色操作演示码（246810）<input id="agent-code" placeholder="仅为模拟验证，不是真实 MFA"></label><button id="agent-do">核对后确认模拟转账</button><button id="agent-cancel">取消本次转账</button></div><div id="agent-unknown" hidden><p>结果未知，请查询原操作回执；禁止重新发起。</p><button id="agent-query">查询模拟成功回执</button></div><button id="agent-events">查看本会话审计</button>';
document.body.append(launch,panel);
const el=id=>document.getElementById(id);let pending=null,inflight=false;
const history=document.createElement('button');history.textContent='查看转账记录';panel.append(history);
history.onclick=async()=>{try{const r=await fetch('/api/snapshot').then(x=>x.json());show(r.data.state.transfer_ops);pending=r.data.state.transfer_ops.find(x=>['awaiting_confirmation','unknown'].includes(x.status))||null;if(pending){el('agent-confirm').hidden=pending.status!=='awaiting_confirmation';el('agent-unknown').hidden=pending.status!=='unknown';el('agent-preview').textContent=`收款人 ${pending.beneficiary_name} · ¥${(pending.amount/100).toFixed(2)} · ${pending.level==='red'?'红色：需模拟验证':'黄色：需明确确认'}`;}}catch(e){show(e.message);}};
const show=value=>el('agent-output').textContent=typeof value==='string'?value:JSON.stringify(value,null,2);
async function call(path,args){
 const data=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':crypto.randomUUID()},body:JSON.stringify(args)}).then(x=>x.json());
 if(data.error)throw Error(data.error.message);return data;
}
function refresh(){window.dispatchEvent(new Event('bank-ledger-refresh'));}
launch.onclick=()=>{panel.hidden=false;el('agent-message').focus();};el('agent-close').onclick=()=>panel.hidden=true;
el('agent-consent').onclick=async()=>{try{await call('/api/rpc',{method:'authorize',args:[{read:true,subscriptions:true,trade:true}]});show('依据：已显式开启本会话演示权限。\n结论：可以查询；金融变更仍需逐项确认。');refresh();}catch(e){show(e.message);}};
el('agent-form').onsubmit=async event=>{event.preventDefault();if(inflight)return;inflight=true;
 try{const r=await call('/api/chat',{message:el('agent-message').value});show(r.data);pending=r.data.preview||pending;
 el('agent-steps').textContent=r.data.plan?'步骤：'+r.data.plan.map(x=>x.tool||x.id).join(' → '):'';
 if(r.data.preview){const op=r.data.preview;el('agent-preview').textContent=`收款人 ${op.beneficiary_name} · ¥${(op.amount/100).toFixed(2)} · ${op.level==='red'?'红色：需模拟验证':'黄色：需明确确认'}`;el('agent-confirm').hidden=false;}
 refresh();}catch(e){show('依据：请求未通过校验或服务不可用。\n结论：'+e.message);}finally{inflight=false;}};
el('agent-do').onclick=async()=>{if(!pending||inflight)return;inflight=true;
 try{let assertion_id;if(pending.level==='red')assertion_id=(await call('/api/transfers/verify',{operation_id:pending.id,code:el('agent-code').value})).data.assertion_id;
 const r=await call('/api/transfers/confirm',{operation_id:pending.id,confirmed:true,assertion_id});show(r.data);el('agent-confirm').hidden=true;el('agent-unknown').hidden=r.data.status!=='unknown';if(r.data.status!=='unknown')pending=null;refresh();
 }catch(e){show('依据：确认未通过或连接中断；先检查操作回执。\n结论：'+e.message);}finally{inflight=false;}};
el('agent-cancel').onclick=async()=>{if(!pending)return;try{show((await call('/api/transfers/cancel',{operation_id:pending.id})).data);pending=null;el('agent-confirm').hidden=true;refresh();}catch(e){show(e.message);}};
el('agent-query').onclick=async()=>{if(!pending)return;try{show((await call('/api/transfers/reconcile',{operation_id:pending.id,result:'success'})).data);pending=null;el('agent-unknown').hidden=true;refresh();}catch(e){show(e.message);}};
el('agent-events').onclick=async()=>{try{show((await fetch('/api/events').then(x=>x.json())).data);}catch(e){show(e.message);}};
})();
