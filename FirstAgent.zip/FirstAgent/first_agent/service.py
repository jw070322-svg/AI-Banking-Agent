"""Single persisted demo ledger. All state changes and receipts commit together."""
from __future__ import annotations
from contextlib import contextmanager, closing
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from uuid import uuid4
import hashlib, json, re, shutil, sqlite3, subprocess, time

from .security import Scanner
from .vendor.eva.data import MockBank, D, POLICY
from .vendor.eva.models import ToolError
from .vendor.eva.tools import ToolRegistry
from .vendor.eva.risk.auth import StepUpAssertion
from .vendor.finance.rule_driven import recommend
from .vendor.rag.corpus import build_index
from .vendor.rag.service import RAGService
from .vendor.security.gate import Principal, ToolPolicy, SecurityGate

BASE=Path(__file__).resolve().parents[1]
SCHEMA='1.0.0'
POLICY_VERSION='integrated-demo-1.0'
METHODS={'authorize','configure','select','setProfile','analyze','summary','reviewSubscription','keep','budget','propose','cancel','verify','execute','reconcile','settle','advance','pause','resume','unlock','liquid','projection','interpret','eligibility','total','capacity','monthlySaved'}
READ={'analyze','summary','reviewSubscription','keep','reconcile','settle'}

def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(value):return 'sha256:'+hashlib.sha256(canonical(value).encode()).hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat()
def integer(value,minimum=0):
    if type(value) is not int or not minimum<=value<=1_000_000_000:
        raise Fault('INVALID_ARGUMENT','金额必须为范围内的整数分')
    return value

class Fault(Exception):
    def __init__(self,code,message,status=400):self.code,self.message,self.status=code,message,status

class AgentService:
    def __init__(self,db_path=None,clock=time.time):
        self.db_path=Path(db_path or BASE/'runtime/agent.sqlite3')
        self.db_path.parent.mkdir(parents=True,exist_ok=True)
        self.clock=clock; self.scanner=Scanner()
        self.node=shutil.which('node')
        if not self.node:raise RuntimeError('Node.js is required for the teammate business engine')
        with closing(self.connect()) as db:
            db.executescript('''CREATE TABLE IF NOT EXISTS sessions(sid TEXT PRIMARY KEY,state TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS requests(sid TEXT,key TEXT,hash TEXT,response TEXT,PRIMARY KEY(sid,key));
            CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,sid TEXT,at TEXT,action TEXT,status TEXT,detail TEXT);''')
        index=BASE/'knowledge/index.json'
        if not index.exists():build_index(BASE/'knowledge/manifest.json',index)
        self.rag=RAGService(index)
        self.gate=SecurityGate({n:ToolPolicy(scope,'write' if n=='transfer' else 'read') for n,scope in {
            'accounts':'account:read','transactions':'transactions:read','subscriptions':'subscriptions:read',
            'transfer':'transfer:write','recommend':'products:read','knowledge':'knowledge:read'}.items()},POLICY_VERSION)

    def connect(self):
        db=sqlite3.connect(self.db_path,timeout=20,isolation_level=None)
        db.execute('PRAGMA journal_mode=WAL'); return db

    @contextmanager
    def transaction(self):
        db=self.connect()
        try:
            db.execute('BEGIN IMMEDIATE');yield db;db.commit()
        except BaseException:db.rollback();raise
        finally:db.close()

    def engine(self,state=None,method=None,args=None):
        proc=subprocess.run([self.node,str(BASE/'first_agent/engine_worker.cjs')],input=canonical({'state':state,'method':method,'args':args or []}),
                            text=True,encoding='utf-8',capture_output=True,timeout=15,cwd=BASE)
        if proc.returncode:raise Fault('ENGINE_FAILURE','业务引擎运行失败',500)
        return json.loads(proc.stdout)

    def create_session(self):
        sid=uuid4().hex+uuid4().hex
        state=self.engine()['state']; state.update(customer_id='CUST-001',session_id=sid,transfer_ops=[],daily_transfers={},task_log=[],clarification=None)
        with self.transaction() as db:
            db.execute('INSERT INTO sessions VALUES(?,?)',(sid,canonical(state)))
            self.audit(db,sid,'session.create','succeeded',{'simulated':True})
        return sid

    def load(self,db,sid):
        row=db.execute('SELECT state FROM sessions WHERE sid=?',(sid,)).fetchone()
        if not row:raise Fault('AUTH_REQUIRED','演示会话不存在，请重新进入',401)
        return json.loads(row[0])

    def audit(self,db,sid,action,status,detail):
        db.execute('INSERT INTO audit(sid,at,action,status,detail) VALUES(?,?,?,?,?)',
                   (sid,stamp(),action,status,canonical(self.scanner.redact_obj(detail))))

    def envelope(self,result=None,status='succeeded',error=None,trace=None):
        return {'schema_version':SCHEMA,'request_id':uuid4().hex,'status':status,'data':result,
                'error':error,'trace':trace or [],'simulated':True}

    def require(self,state,tool):
        scopes={'knowledge:read','products:read'}
        if state['consent']['read']:scopes.update({'account:read','transactions:read','subscriptions:read'})
        if state['consent']['trade']:scopes.add('transfer:write')
        principal=Principal(state['customer_id'],frozenset(scopes),frozenset({state['customer_id']}))
        decision=self.gate.check(principal,tool,state['customer_id'])
        if decision.decision!='pass' and not (tool=='transfer' and decision.decision=='review'):
            raise Fault('SCOPE_DENIED','缺少对应演示权限',403)

    def call(self,sid,action,args=None,key=None):
        args={} if args is None else args
        try: request_hash=digest({'action':action,'args':args})
        except (ValueError,TypeError):return self.envelope(error={'code':'INVALID_ARGUMENT','message':'参数无法规范化'},status='rejected')
        with self.transaction() as db:
            state=self.load(db,sid)
            if key:
                if not isinstance(key,str) or not 1<=len(key)<=128:raise Fault('INVALID_ARGUMENT','无效幂等键')
                old=db.execute('SELECT hash,response FROM requests WHERE sid=? AND key=?',(sid,key)).fetchone()
                if old:
                    if old[0]!=request_hash:raise Fault('IDEMPOTENCY_CONFLICT','同一幂等键不能提交不同参数',409)
                    return json.loads(old[1])
            previous=deepcopy(state)
            try:
                result=self.dispatch(db,state,action,args)
                status=(result.pop('_status',result.get('status','succeeded')) if isinstance(result,dict) else 'succeeded')
                if status not in {'succeeded','awaiting_confirmation','needs_input','unknown','processing','failed','cancelled','invalidated'}:status='succeeded'
                response=self.envelope(result,status)
            except (Fault,ToolError) as exc:
                if not getattr(exc,'persist',False):state=previous
                response=self.envelope(status='rejected',error={'code':exc.code,'message':self.scanner.redact_text(getattr(exc,'message',str(exc)))})
            except (TypeError,ValueError,KeyError,IndexError) as exc:
                state=previous
                response=self.envelope(status='rejected',error={'code':'INVALID_ARGUMENT','message':'参数类型、数量或内容不符合接口约定'})
            self.audit(db,sid,action,response['status'],{'request_hash':request_hash,'arguments':args,'error':response['error']})
            db.execute('UPDATE sessions SET state=? WHERE sid=?',(canonical(state),sid))
            if key:db.execute('INSERT INTO requests VALUES(?,?,?,?)',(sid,key,request_hash,canonical(response)))
            return response

    def pending(self,state,op_id):
        for op in state['operations']+state['transfer_ops']:
            if op['id']==op_id:return op
        raise Fault('NOT_FOUND','未找到当前会话的操作',404)

    def bound_hash(self,state,op):
        # Explicit canonical binding shared by preview, assertion, commit and audit.
        return digest({'user_id':state['customer_id'],'session_id':state['session_id'],
                       'operation_id':op['id'],'type':op['type'],'target':op['target'],'amount_minor':op['amount'],
                       'version':op['version'],'policy_version':POLICY_VERSION,'expires_at':op['expires_at']})

    def attach(self,state,op):
        op['expires_at']=int(self.clock())+300;op['policy_version']=POLICY_VERSION
        op['preview_hash']=self.bound_hash(state,op)
        return deepcopy(op)

    def check_pending(self,state,op):
        if op['status']!='awaiting_confirmation':raise Fault('INVALID_STATE','操作已提交、取消或失效')
        if self.clock()>=op.get('expires_at',0):
            op['status']='invalidated';e=Fault('PREVIEW_EXPIRED','预览已过期，请重新生成');e.persist=True;raise e
        if op['version']!=state['version'] or op.get('preview_hash')!=self.bound_hash(state,op):
            raise Fault('PREVIEW_STALE','参数、权限或账本已变化，请重新预览')
        if op.get('policy_version')!=POLICY_VERSION:raise Fault('POLICY_CHANGED','策略已变化，请重新预览')

    def engine_call(self,state,method,args):
        response=self.engine(state,method,args)
        state.clear();state.update(response['state'])
        if response['error']:
            e=Fault('POLICY_DENIED',response['error']);e.persist=True;raise e
        return response['result']

    def invalidate_transfers(self,state):
        for op in state['transfer_ops']:
            if op['status']=='awaiting_confirmation' and op['version']!=state['version']:op['status']='invalidated'

    def dispatch(self,db,state,action,args):
        if action=='rpc':
            method=args.get('method');params=args.get('args',[])
            if method not in METHODS:raise Fault('TOOL_NOT_REGISTERED','不支持的业务工具')
            if not isinstance(params,list) or len(params)>4:raise Fault('INVALID_ARGUMENT','工具参数必须为数组且不超过四项')
            if method=='interpret':
                if not params or not isinstance(params[0],str):raise Fault('INVALID_ARGUMENT','意图文本必须为字符串')
                if self.scanner.scan_input(params[0]).injection_suspected:raise Fault('INJECTION_BLOCKED','检测到绕过权限或审批的指令')
                params=[self.scanner.redact_text(params[0])]
            if method in READ:self.require(state,'accounts')
            if method not in {'authorize','cancel','pause','resume','unlock','interpret','eligibility','total','capacity','monthlySaved','projection','summary','analyze','reviewSubscription','keep','reconcile','settle'} and any(o['status']=='unknown' for o in state['transfer_ops']):
                raise Fault('UNKNOWN_OPERATION','未知转账尚未核实，禁止后续写入')
            if method=='propose':
                if any(o['status'] in {'unknown','awaiting_confirmation'} for o in state['transfer_ops']):raise Fault('PENDING_OPERATION','请先处理待执行或未知转账')
            if method in {'verify','execute'}:
                op=self.pending(state,params[0]);self.check_pending(state,op)
                if op['type']=='transfer':raise Fault('INVALID_ARGUMENT','转账请使用转账确认接口')
            result=self.engine_call(state,method,params)
            if method=='propose':result=self.attach(state,self.pending(state,result['id']))
            if method=='verify':
                # Real assertion service is replaceable; this branch is explicitly simulated.
                op=self.pending(state,params[0]);op['assertion_expires_at']=self.clock()+120
                op['assertion_hash']=op['preview_hash']
            if method=='execute':
                # Engine checks verified; integration also checks assertion binding / TTL.
                before=self.pending_from_engine_assertion(state,params[0])
            self.invalidate_transfers(state)
            return result
        if action=='snapshot':
            out=self.engine(state);return {'state':self.public_state(state),'catalog':out['catalog'],'total':out['total'],'capacity':out['capacity']}
        if action=='accounts':
            self.require(state,'accounts');return {'account_id':'ACC-4821','currency':'CNY','available_minor':state['available'],
                'positions_minor':sum(p['amount'] for p in state['positions']),'total_minor':self.engine(state)['total'],'version':state['version']}
        if action=='transactions':
            self.require(state,'transactions');month=args.get('month','2026-10')
            return {'items':[x for x in state['transactions'] if x['date'].startswith(month)],'summary':self.engine_call(state,'summary',[month])}
        if action=='subscriptions':self.require(state,'subscriptions');return state['subscriptions']
        if action=='recommend':return self.recommendations(state,args)
        if action=='knowledge':
            question=args.get('question','');result=self.rag.ask(question,args.get('top_k',3))
            result['risk_notice']='团队教育演示资料；未审核为真实银行条款或法规'
            return result
        if action=='transfer.preview':return self.transfer_preview(state,args)
        if action=='transfer.verify':
            op=self.pending(state,args['operation_id']);self.check_pending(state,op);self.require(state,'transfer')
            if op['type']!='transfer':raise Fault('INVALID_ARGUMENT','不是转账操作')
            if args.get('code')!='246810':
                state['failures']+=1
                if state['failures']>=3:state['locked']=True
                e=Fault('AUTH_INVALID','演示验证码错误');e.persist=True;raise e
            assertion=StepUpAssertion('ASSERT-'+uuid4().hex,state['customer_id'],state['session_id'],op['preview_hash'],
                                      stamp(),datetime.fromtimestamp(self.clock()+120,timezone.utc).isoformat())
            op['assertion']={**assertion.__dict__,'expires_epoch':self.clock()+120,'consumed':False}
            return {'assertion_id':assertion.assertion_id,'simulated':True,'expires_at':assertion.expires_at}
        if action=='transfer.confirm':return self.transfer_confirm(state,args)
        if action=='operation':return deepcopy(self.pending(state,args['operation_id']))
        if action=='transfer.reconcile':return self.transfer_reconcile(state,args)
        if action=='transfer.cancel':
            op=self.pending(state,args['operation_id'])
            if op['type']!='transfer':raise Fault('INVALID_ARGUMENT','不是转账操作')
            self.check_pending(state,op);op['status']='cancelled';return deepcopy(op)
        if action=='chat':return self.chat(state,args)
        if action=='events':
            rows=db.execute('SELECT id,at,action,status,detail FROM audit WHERE sid=? ORDER BY id DESC LIMIT 100',(state['session_id'],)).fetchall()
            return [dict(zip(['id','at','action','status','detail'],r)) for r in rows]
        raise Fault('TOOL_NOT_REGISTERED','未注册的接口',404)

    def pending_from_engine_assertion(self,state,op_id):
        # Called after the deterministic engine inside the same DB transaction;
        # failures roll back the entire mutation, including ledger changes.
        op=self.pending(state,op_id)
        if op.get('level')=='red' and (self.clock()>=op.get('assertion_expires_at',0) or op.get('assertion_hash')!=op.get('preview_hash')):
            raise Fault('AUTH_EXPIRED','演示验证过期或绑定不符，请重新验证')
        return op

    def public_state(self,state):
        result=deepcopy(state)
        result.pop('session_id',None)
        for op in result['operations']+result['transfer_ops']:op.pop('assertion',None)
        return result

    def transfer_policy(self,state,args):
        self.require(state,'transfer')
        if not state['active'] or state['locked']:raise Fault('EXECUTION_LOCKED','任务暂停或执行锁定')
        if any(o['status']=='unknown' for o in state['operations']+state['transfer_ops']):raise Fault('UNKNOWN_OPERATION','先查询未知操作回执，不能重复执行')
        amount=integer(args.get('amount_minor'),1)
        bank=MockBank();account=bank.find_account('CUST-001',args.get('account_id','ACC-4821'))
        if account['account_id']!='ACC-4821':raise Fault('UNSUPPORTED_ACCOUNT','首版统一账本只支持 ACC-4821 转出')
        account['balance']=account['available']=D(Decimal(state['available'])/100)
        day=datetime.fromtimestamp(state['day']/1000,timezone.utc).date().isoformat()
        used=state['daily_transfers'].get(day,0)
        bank.daily_transfer_total=lambda *a,**kw:D(Decimal(used)/100)
        _,beneficiary,_=ToolRegistry(bank)._validate_transfer('CUST-001','ACC-4821',args.get('beneficiary_name',''),Decimal(amount)/100)
        return amount,beneficiary,day,used

    def transfer_preview(self,state,args):
        amount,beneficiary,day,used=self.transfer_policy(state,args)
        if any(o['status'] in {'unknown','awaiting_confirmation'} for o in state['operations']+state['transfer_ops']):
            raise Fault('PENDING_OPERATION','请先处理已有待确认或未知操作')
        op={'id':'TR-'+uuid4().hex,'type':'transfer','target':beneficiary['beneficiary_id'],'beneficiary_name':beneficiary['name'],
            'amount':amount,'account_id':'ACC-4821','version':state['version'],'status':'awaiting_confirmation',
            'level':'red' if used+amount>100000 else 'yellow','created_at':stamp(),'day':day,
            'request':{'amount_minor':amount,'beneficiary_name':beneficiary['name'],'account_id':'ACC-4821'}}
        state['transfer_ops'].append(op);self.attach(state,op)
        return deepcopy(op)

    def transfer_confirm(self,state,args):
        op=self.pending(state,args['operation_id'])
        if op['type']!='transfer':raise Fault('INVALID_ARGUMENT','不是转账操作')
        self.check_pending(state,op)
        amount,beneficiary,day,used=self.transfer_policy(state,op['request'])
        if args.get('confirmed') is not True:raise Fault('APPROVAL_REQUIRED','必须明确确认具体转账')
        if op['level']=='red' or used+amount>100000:
            assertion=op.get('assertion',{})
            if (assertion.get('assertion_id')!=args.get('assertion_id') or assertion.get('consumed',True)
                or self.clock()>=assertion.get('expires_epoch',0) or assertion.get('preview_hash')!=op['preview_hash']
                or assertion.get('user_id')!=state['customer_id'] or assertion.get('session_id')!=state['session_id']):
                raise Fault('AUTH_REQUIRED','需要与本次预览绑定且未过期的演示验证断言')
            assertion['consumed']=True
        outcome=args.get('outcome','success')
        if outcome not in {'success','failed','unknown'}:raise Fault('INVALID_ARGUMENT','无效模拟结果')
        if outcome=='unknown':op['status']='unknown'
        elif outcome=='failed':
            op['status']='failed';state['failures']+=1
            if state['failures']>=3:state['locked']=True
        else:self.apply_transfer(state,op,day,used)
        return deepcopy(op)

    def apply_transfer(self,state,op,day,used):
        state['available']-=op['amount'];state['initialTotal']-=op['amount'];state['version']+=1
        state['daily_transfers'][day]=used+op['amount'];op['status']='succeeded';op['receipt_id']='RCPT-'+uuid4().hex
        state['failures']=0
        state['transactions'].append({'id':op['receipt_id'],'date':day,'name':'转账给'+op['beneficiary_name'],'category':'transfer','amount':-op['amount'],'status':'booked','source':'持久化模拟银行回执'})
        for other in state['operations']+state['transfer_ops']:
            if other['status']=='awaiting_confirmation':other['status']='invalidated'
        # The completed operation is no longer awaiting confirmation.
        op['status']='succeeded'
        state['goal']['total']=min(state['goal']['total'],state['available'])
        state['amount']=min(state['amount'],max(0,state['goal']['total']-state['goal']['need']-state['goal']['emergency']))
        self.engine(state) # Ledger invariant must still hold before SQLite commit.

    def transfer_reconcile(self,state,args):
        self.require(state,'accounts');op=self.pending(state,args['operation_id'])
        if op['type']!='transfer' or op['status']!='unknown':raise Fault('INVALID_STATE','没有待查询的未知转账')
        result=args.get('result')
        if result=='success':
            day=op['day'];used=state['daily_transfers'].get(day,0)
            # No writes were allowed while this result was unknown.
            if op['amount']>state['available']:raise Fault('LEDGER_CONFLICT','未知转账核验时余额冲突')
            self.apply_transfer(state,op,day,used)
        elif result=='failed':op['status']='failed'
        elif result!='pending':raise Fault('INVALID_ARGUMENT','无效回执结果')
        return deepcopy(op)

    def recommendations(self,state,args):
        self.require(state,'recommend')
        out=self.engine(state);products=[]
        for p in out['catalog']:
            products.append({'product_id':p['id'],'name':p['name'],'risk_level':p['risk'],'min_investment_cny':p['min']/100,
                'lockup_days':p['term']*30,'redemption_days':1,'category':'cash' if not p['term'] else 'fixed_income',
                'objectives':['liquidity'] if not p['term'] else ['income'],'active':True,'facts_verified':p['redemption']!='unsupported',
                'currency':'CNY','annual_fee_pct':None if p['redemption']=='unsupported' else 0})
        # Calendar days include next-day settlement; engine eligibility remains binding too.
        profile={'user_id':state['customer_id'],'risk_tolerance':1 if state['profile']=='valid' else None,'risk_capacity':1,
                 'budget_cny':min(state['amount'],out['capacity'])/100,'horizon_days':state['goal']['months']*30,'max_redemption_days':1,'objective':args.get('objective','liquidity'),'preferred_categories':['cash']}
        result=recommend(profile,products,args.get('top_k',3));result['money_unit']='CNY minor units at external boundary; ranking adapter alone converts to CNY'
        return result

    def chat(self,state,args):
        text=args.get('message','')
        if not isinstance(text,str) or not 1<=len(text.strip())<=2000:raise Fault('INVALID_ARGUMENT','请输入 1–2000 个字符')
        if self.scanner.scan_input(text).injection_suspected:raise Fault('INJECTION_BLOCKED','检测到绕过权限或审批的指令')
        if re.search('他人|别人|朋友的|家人的',text):raise Fault('OWNERSHIP_DENIED','只能处理当前演示客户的账户')
        if re.search('取消|不转了',text) and state.get('clarification'):
            state['clarification']=None;return {'intent':'cancel','analysis':'已取消待澄清请求','conclusion':'未执行资金操作'}
        if re.search('转账|转给',text) or state.get('clarification'):
            prior=state.get('clarification') or {};bank=MockBank()
            names=[b['name'] for b in bank.beneficiaries.values() if b['name'] in text and b['customer_id']=='CUST-001']
            amounts=re.findall(r'(?<![\d.])(\d+(?:\.\d{1,2})?)\s*元',text)
            values={'beneficiary_name':names[0] if len(names)==1 else prior.get('beneficiary_name'),
                    'amount_minor':int(Decimal(amounts[0])*100) if len(amounts)==1 else prior.get('amount_minor')}
            if len(names)>1:values['beneficiary_name']=None
            if len(amounts)>1:values['amount_minor']=None
            if not values['beneficiary_name'] or values['amount_minor'] is None:
                state['clarification']=values
                return {'intent':'transfer','_status':'needs_input','analysis':'缺少唯一收款人或明确金额，不能可靠生成转账预览',
                        'missing':[k for k,v in values.items() if v is None],'conclusion':'请提供收款人姓名及金额，例如：给张三转账 800 元'}
            state['clarification']=None;preview=self.transfer_preview(state,values)
            return {'intent':'transfer','_status':'awaiting_confirmation','analysis':'已解析收款人和金额，并完成权限、余额、名册与累计额度检查',
                    'plan':[{'id':'read','depends_on':[]},{'id':'preview','depends_on':['read']},{'id':'confirm','depends_on':['preview']},{'id':'receipt','depends_on':['confirm']}],
                    'preview':preview,'conclusion':'请核对预览后明确确认；对话不自动扣款'}
        tasks=[]
        if re.search('余额|多少钱',text):tasks.append(('accounts',{}))
        if re.search('账单|消费|支出|现金流|储蓄率',text):tasks.append(('transactions',{'month':args.get('month','2026-10')}))
        if re.search('订阅|扣费',text):tasks.append(('subscriptions',{}))
        if re.search('理财|推荐|投资',text):tasks.append(('recommend',{}))
        if not tasks:tasks=[('knowledge',{'question':text})]
        results=[];plan=[]
        for i,(tool,params) in enumerate(tasks):
            plan.append({'id':str(i+1),'tool':tool,'depends_on':[str(i)] if i else []})
            if tool=='accounts':self.require(state,'accounts');data={'available_minor':state['available'],'currency':'CNY'}
            elif tool=='transactions':self.require(state,'transactions');data=self.engine_call(state,'summary',[params['month']])
            elif tool=='subscriptions':self.require(state,'subscriptions');data=deepcopy(state['subscriptions'])
            elif tool=='recommend':data=self.recommendations(state,{})
            else:data=self.rag.ask(text,3)
            results.append({'tool':tool,'result':data})
        log={'at':stamp(),'message':self.scanner.redact_text(text),'plan':plan,'status':'succeeded'}
        state['task_log'].append(log)
        return {'intent':'multi_task' if len(tasks)>1 else tasks[0][0],'analysis':'按已授权业务工具读取数据；知识问题仅返回可追溯原文依据',
                'plan':plan,'results':results,'conclusion':'本轮查询完成；未自动执行金融变更'}
