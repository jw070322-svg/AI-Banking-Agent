"""Run behavioral suites and publish machine-readable verification evidence."""
from pathlib import Path
from datetime import datetime, timezone
import io, json, subprocess, sys, unittest

ROOT=Path(__file__).resolve().parent

def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_integration.py')
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    (ROOT/'reports/integration-tests.txt').write_text(stream.getvalue(),encoding='utf-8')
    node=subprocess.run(['node',str(ROOT/'tests/vv_core.cjs')],capture_output=True,text=True,encoding='utf-8',cwd=ROOT)
    vv=json.loads(node.stdout) if node.returncode==0 else {'passed':0,'error':node.stderr}
    (ROOT/'reports/vv-tests.json').write_text(json.dumps(vv,ensure_ascii=False,indent=2),encoding='utf-8')
    report={'verified_at':datetime.now(timezone.utc).isoformat(),
            'integration':{'run':result.testsRun,'passed':result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),
                'failures':[str(t) for t,_ in result.failures],'errors':[str(t) for t,_ in result.errors],'skipped':[str(t) for t,_ in result.skipped]},
            'vv_engine':vv,'conclusion':'passed' if result.wasSuccessful() and node.returncode==0 else 'failed'}
    (ROOT/'reports/verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['conclusion']=='passed' else 1

if __name__=='__main__':sys.exit(main())
